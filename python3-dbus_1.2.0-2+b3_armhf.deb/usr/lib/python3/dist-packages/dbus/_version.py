# dbus/_version.py.  Generated from _version.py.in by configure.
version = (1, 2, 0)
__version__ = "1.2.0"
